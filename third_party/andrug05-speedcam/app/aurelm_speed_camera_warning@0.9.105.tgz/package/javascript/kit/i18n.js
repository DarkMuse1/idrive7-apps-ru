'use strict'; const l=require('../i18n'); module.exports={t:l.t,dict:{},getLanguage:l.language};
