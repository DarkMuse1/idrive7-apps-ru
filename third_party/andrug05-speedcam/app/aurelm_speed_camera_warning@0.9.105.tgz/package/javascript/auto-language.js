'use strict';
// Display language follows the HU. Do not persist settings or touch camera/vehicle commands.
const HMI = [
 ['de.bmw.infotainment.hmi.hmicontext.HMIContext','HMI_CID'],
 ['de.bmw.infotainment.hmi.hmicontext2.HMIContext2','1']
];
function language(value) {
 if(value&&typeof value==='object')return language(value.currentDisplayLanguage!==undefined?value.currentDisplayLanguage:value.value);
 return /^(ru(?:-|_|$)|russisch|russian)/i.test(String(value||''))?'ru':'en';
}
function attach(ctx,apply) {
 let closed=false,current=null;const subscriptions=[];
 function update(value){if(closed)return;const next=language(value);if(next===current)return;current=next;apply(next);}
 function stop(){if(closed)return;closed=true;subscriptions.splice(0).forEach(s=>{try{s.shutdown();}catch(e){}});}
 const signals=ctx.signals||require('./kit/signals');
 if(ctx.app&&ctx.app.once)ctx.app.once('shutdown',stop);
 update('en');
 HMI.forEach(pair=>Promise.resolve().then(()=>closed?null:signals.watch(pair[0],pair[1],{currentDisplayLanguage:update},ctx.log)).then(sub=>{
  if(!sub)return;if(closed)sub.shutdown();else subscriptions.push(sub);
 }).catch(e=>{if(!closed&&ctx.log&&ctx.log.warn)ctx.log.warn('HU language: '+String(e&&e.message||e));}));
 return stop;
}
module.exports={attach,language};
